﻿namespace XFDraw
{
    public interface ISketchController
    {
        void SendSketchUpdated();
    }
}
