﻿using Xamarin.Forms;

namespace XFDraw
{
    class HyperlinkLabel : Label
    {
    }
}
