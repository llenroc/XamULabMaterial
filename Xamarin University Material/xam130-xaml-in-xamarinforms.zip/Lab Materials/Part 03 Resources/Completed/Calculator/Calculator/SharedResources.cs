﻿using System;
using Xamarin.Forms;

namespace Calculator
{
    public static class SharedResources
    {
        public static Color OpButtonBkColor
        {
            get { return Color.FromRgb(0xff, 0xa5, 0); }
        }
    }
}

