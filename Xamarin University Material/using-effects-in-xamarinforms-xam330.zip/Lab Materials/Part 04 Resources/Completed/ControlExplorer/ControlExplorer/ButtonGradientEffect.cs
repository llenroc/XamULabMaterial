﻿using Xamarin.Forms;

namespace ControlExplorer
{
	public class ButtonGradientEffect : RoutingEffect
	{
	    public ButtonGradientEffect () : base ("Xamarin.ButtonGradientEffect") 
		{}
	}
}